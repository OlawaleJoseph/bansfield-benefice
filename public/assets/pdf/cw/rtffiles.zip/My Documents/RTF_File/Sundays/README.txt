README.TXT


WELCOME TO THE COMMON WORSHIP TEXT DISKS!
    
We hope that you will find these text disks useful in preparing 
 service sheets and other resources. Please take a moment to read
 over the information below before you begin.

In this file:
* What is on the text disks?
* Where has the material come from?
* How to use the disks
* How to find the texts you need
* Note about formatting and the 'All' rubric
* If you have trouble using the files...
* Copyright information, licence and local editions




WHAT IS ON THE TEXT DISKS?

There are four disks, each containing a different group of texts: 
Disk 1. Holy Communion, Service of the Word, Morning and
 Evening Prayer, Night Prayer, plus Authorization, Copyright
 and Acknowledgements information;
Disk 2: Calendar, Lectionary, Collects, Post Communions,
 Canticles and Psalter;
Disk 3. Initiation Services (Baptism, Confirmation and
 associated services and material);
Disk 4. Pastoral Services (Wholeness and Healing; Marriage;
 Funerals).





WHERE HAS THE MATERIAL COME FROM?
The material is taken from the following printed books:
Common Worship: Services and Prayers for the Church of
 England (CHP, 2000)
Common Worship: President's Edition (CHP, 2000)
Common Worship: Pastoral Services (CHP, 2000)
Common Worship: Initiation Services (CHP, 1998)
A Brief Guide to Liturgical Copyright (CHP, 2000)

Notes:
1. Where material is repeated in more than one book, we have only 
 included it once.
2. The Initiation Services book was published in 1998 in an
 interim edition. These disks contain an updated version of 
 the material, revised in order to conform it to Common Worship
 and to take into account amendments made to the material by the
 General Synod.
3. The music from the President's edition has not been included.




HOW TO USE THE DISKS

If you have sufficient hard disk space on your computer, we
 recommend that you copy the contents of each disk onto your
 hard drive, as this will make access to the files faster 
 and more reliable. This will also mean that you can store the
 original disks away as master copies, so that if you 
 accidentally alter the files you will always be able 
 to restore the originals. 

The disks should be stored carefully, away from heat, moisture,
 and sources of electromagnetism. This should help to prevent
 the disks from becoming corrupted over time. If you wish you may
 also make one single copy of each disk for backup purposes only.

The material from the books has been split down into sections so 
 that you don't have to scroll through a huge amount of text to
 find the service or resource that you need. However, in order to
 make the best use of the disks' capacity, we have not created 
 individual files for every single service. 

With the exception of this readme file, all the files are saved
 as RTF (rich text format) files. This is a standardized file
 type that can be read by most word processing software packages. 

Your word processor may prompt you to "convert from RTF" when you 
 try to open the files; if so, just OK the conversion process and
 the file should open correctly.

To find out which file you need, consult the content*.rtf file
 stored on each disk. There is more information about how
 to find files in HOW TO FIND THE TEXTS YOU NEED, below. Also,
 a full contents list for all disks is provided at the end of
 this file.





HOW TO FIND THE TEXTS YOU NEED

You may find it useful to have a copy of one of the printed books
 to hand, to help you to search quickly for the texts that you
 need and to check up on layout and formatting. 

As far as is possible, we have given each file a filename that
 gives an indication of what texts are included. 

Where there are both traditional and contemporary language
 versions of a particular resource or service, the filename will
 indicate this with the letters c or t (or occasionally, tra).

There is a Contents list on each disk for reference. A full
 contents list detailing all four disks and their contents is
 provided at the bottom of this readme file.




NOTE ABOUT FORMATTING AND THE 'ALL' RUBRIC

In order to ensure that the text is readable by a wide range of 
 systems, we have had to make some compromises in layout and
 formatting. We hope that you will understand that the aim of 
 these disks is to provide the texts to as many people as 
 possible, and so access to the files has to be the highest 
 priority.

The level of formatting retained in the files when you open them 
 will depend in part on your system and software setup. If you're 
 opening them in recent versions of Word or Wordpad you should
 see red/black colour as appropriate, bold and italic formatting,
 and various font sizes.

In the book, some headings are right-aligned. We have not been
 able to reproduce this successfully across different software
 so all headings in these files have been 
 left-aligned.

We have had to remove the 'All' rubric, as the
 tab/margin settings and indent styles necessary to include it
 caused difficulties for some of the systems on which we tested
 the files.

Special characters do not display consistently across systems,
 and you may find that the decorative paragraph symbol (reverse
 P) used in some headings, the dagger/cross symbol and the ellipsis
 do not display properly. All Hebrew characters (e.g. those in 
 Psalm 119) have been removed.

You may notice that lines do not all begin flush with each other,
 eg in a psalm where verse numbers are given these will throw out
 the alignment. We apologize for this, but again, this was caused
 by the need to avoid using margins and indents wherever 
 possible, as these do not display consistently across the range
 of systems and software that we are aiming to support. 

We would advise that if you are using the texts to produce local
 orders of service, you have a book to hand where possible, in
 order to confirm appropriate formatting, special characters, and
 position of the 'All' rubrics.




IF YOU HAVE TROUBLE USING THE FILES

If you have never used RTF files before, or are using new or
 recently upgraded software to access the files, please consult
 the manual/online help that came with your word-processing or
 DTP package for accurate information related to your particular
 setup. Try looking up "RTF", "file types" or "import" in its
 index. A small number of software packages may require special
 optional filters to be installed in order to read RTF files,
 and it is possible that you did not choose to install the filter
 when you installed or reinstalled the software package. The
 manual or online help should explain how to set up the
 software to read and use files in Rich Text Format.

If you are able to read other RTF files using the same hardware
 and software setup, but still can't read the files on these
 disks, please get in touch using the CONTACT DETAILS below.
 Please be sure to describe the problem in full, including any
 error messages that you encountered. We have tested these disks
 on as many system/software setups as we could, but it is 
 possible that there may be some problems as yet unreported,
 and if that is the case, we will endeavour to fix them.

If you get an error message similar to "A:/ A device attached
 to the system is not functioning" when you try to access the
 files, please contact us using the CONTACT DETAILS below, as
 it is probable that your disk/s are faulty. If you are running
 a recent version of Windows, you can confirm this by running 
 ScanDisk (from Accessories/System Tools/ScanDisk) on the
 affected disk/s. If errors are reported in this process,
 the disk is corrupt.



COPYRIGHT INFORMATION, LICENCE, AND LOCAL EDITIONS

Copyright (c) The Archbishops' Council 2000

Some texts have been reproduced with permission from other
 copyright holders. Please see the acknowledgements in 
 copyrt.rtf on disk one for full details.

All rights reserved. No part of this publication may be 
 reproduced in any form or by any means, electronic or 
 mechanical, including  photocopying, recording, or any
 information storage and retrieval system, except as
 stated below, without written permission.

You may make one single copy of each disks for backup 
 purposes only.

Texts for local use: special arrangements apply to local 
 editions of services. These cover reproduction on a 
 non-commercial basis both for a single occasion and for 
 repeated use. Full details are available in A Brief Guide to
 Liturgical Copyright, which is included on disk one as
 litcopy.rtf.

In general, the copyright notice that should be included on
 local editions takes the following form:

Common Worship: Services and Prayers for the Church of England
 [or other title, as appropriate], material from which is 
 included in this service, is copyright (c) The Archbishops'
 Council 2000. 

However, you should make sure to consult A Brief Guide... for
 full details, as the exact wording will vary according to the
 choice of material included in your service.

Please also note that by buying this package you are only 
 licensed to use the disks on a single computer. Please 
 purchase additional copies if you wish additional users 
 to have access to the text disks. Remember that if your 
 intended additional users have Internet access they can read
 the material online for free at www.commonworship.com. Text
 can be copied and pasted from the material on the web site as
 well as from these disks, subject to the copyright 
 restrictions mentioned above. 




CONTACT DETAILS

In case of query please contact:

Common Worship Text Disks
Church House Publishing
Great Smith Street 
LONDON
SW1P 3NZ

Email: electronic.publishing@c-of-e.org.uk
Fax: 020 7898 1449




CONTENTS LISTS

The filenames are listed first, followed by the contents of
 each file.



CONTENTS OF DISK ONE

readme.txt	The readme file you are now reading
content1.rtf	Contents of disk one
copyrt.rtf	Authorization, Acknowledgements and Sources
litcopy.rtf	A Brief Guide to Liturgical Copyright

Holy Communion Folder (disk 1 - hc)
hc_notes.rtf	Notes on Holy Communion
hc_prep.rtf	A Form of Preparation
order_1.rtf	Holy Communion Order One
eps_ord1.rtf	Eucharistic Prayers A to H for use with 
		 Holy Communion Order One (contemporary)
ord1_tra.rtf	Holy Communion Order One in Traditional Language
		 (includes Eucharistic Prayers)
order_2.rtf	Holy Communion Order Two
order_2c.rtf	Holy Communion Order Two in Contemporary Language
hc_supl1.rtf	Supplementary Texts (part 1)
hc_supl2.rtf	Supplementary Texts (part 2)
hc_seas1.rtf	Seasonal Provisions (part 1)
hc_seas2.rtf	Seasonal Provisions (part 2)
hc_seas3.rtf	Seasonal Provisions (part 3)
pres_whl.rtf	Provisions for Wholeness and Healing Services
		 from the President's Edition
pres_mrg.rtf	Provisions for Marriage Services from the
		 President's Edition
pres_fnl.rtf	Provisions for Funeral Services from the
		 President's Edition


Service of the Word, Morning and Evening Prayer, Night Prayer
 Folder (disk 1 - swmornev)
word.rtf	A Service of the Word
morning.rtf	Morning Prayer on Sunday
evening.rtf	Evening Prayer on Sunday
thanksme.rtf	Thanksgivings for Use at Morning and 
		 Evening Prayer on Sunday
morn_bcp.rtf	Morning Prayer from the Book of Common Prayer
eve_bcp.rtf	Evening Prayer from the Book of Common Prayer
night_c.rtf	Night Prayer (Compline) in Contemporary Language
night_t.rtf	Night Prayer (Compline) in Traditional Language
litany.rtf	Prayers for Various Occasions, the Litany and
		 the Litany from the Book of Common Prayer
confess.rtf	Authorized Forms of Confession and Absolution
creeds.rtf	Creeds and Authorized Affirmations of Faith


*************************************************************


CONTENTS OF DISK TWO

content2.rtf	Contents of disk two

Calendar Folder (disk 2 - calendar)
declarat.rtf	Preface from Common Worship: Services and
		 Prayers for the Church of England and the
		 Declaration of Assent
seasons.rtf	Calendar - The seasons
holydays.rtf	Calendar - Holy Days
easterva.rtf	Calendar - The date of Easter and other
		 variable dates
rules.rtf	Rules for regulating Authorized Forms of 
		 Service, Rules to order the Christian Year, 
		 and A Table of Transferences


Collects Folder (disk 2 - collects)
Collects and Post Communions (contemporary language):
c_advent.rtf	Advent (contemporary)
c_christ.rtf	Christmas (contemporary)
c_epipha.rtf	Epiphany (contemporary)
c_ord_le.rtf	Ordinary Time until start of Lent (contemporary)
c_lent.rtf	Lent (contemporary)
c_easter.rtf	Easter (contemporary)
c_ord_tr.rtf	Ordinary Time until the Last Sunday after
		 Trinity (contemporary)
c_all-ad.rtf	All Saints Day to Christ the King (contemporary)
c_fst_ja.rtf	Festivals (January to end of July - contemporary)
c_fst_au.rtf	Festivals (August to December and
		 Harvest Thanksgiving - contemporary)
c_jan_ls.rtf	Lesser Festivals: January to April (contemporary)
c_may_ls.rtf	Lesser Festivals: May to August (contemporary)
c_sep_ls.rtf	Lesser Festivals: September to December 
		 (contemporary)
c_com_ss.rtf	Lesser Festivals: Common of the Saints 
		 (contemporary)
c_occas.rtf	Lesser Festivals: Special Occasions 
		 (contemporary)

Collects and Post Communions (traditional language):
t_advent.rtf	Advent (traditional)
t_christ.rtf	Christmas (traditional)
t_epipha.rtf	Epiphany (traditional)
t_ord_le.rtf	Ordinary Time until start of Lent (traditional)
t_lent.rtf	Lent (traditional)
t_easter.rtf	Easter (traditional)
t_ord_tr.rtf	Ordinary Time until the Last Sunday after
		 Trinity (traditional)
t_all-ad.rtf	All Saints Day to Christ the King (traditional)
t_fst_ja.rtf	Festivals (January to end of July - traditional)
t_fst_au.rtf	Festivals (August to December and
		Harvest Thanksgiving - traditional)
t_jan_ls.rtf	Lesser Festivals: January to April (traditional)
t_may_ls.rtf	Lesser Festivals: May to August (traditional)
t_sep_ls.rtf	Lesser Festivals: September to December
		 (traditional)
t_com_ss.rtf	Lesser Festivals: Common of the Saints
		 (traditional)
t_occas.rtf	Lesser Festivals: Special Occasions
		 (traditional)


Lectionary for Sundays, Principal Holy Days and Festivals
 (disk 2 - lection)
Lectionary tables:
lec_rul.rtf	Lectionary years, Rules to order how the
		 Psalter and the rest of Holy Scripture
		 are appointed to be read
lec_adv.rtf	Advent through to Easter Eve
lec_eas.rtf	Easter through to beginning of July (Proper 8)
lec_jul.rtf	July to the Last Sunday after Trinity
lec_alls.rtf	All Saints Day to Christ the King
lec_fst1.rtf	Festivals (January to end of July)
lec_fst2.rtf	Festivals (August to December, including 
		Harvest Thanksgiving)
alt_psa.rtf	Alternative Psalmody for Principal and 
		 Second Service


Canticles Folder (disk 2 - canticle)
opening.rtf	Opening Hymn and Canticles at Morning 
		 and Evening Prayer
oldandnw.rtf	Old and New Testament Canticles at Morning
		 and Evening Prayer
gospel.rtf	Gospel Canticles
other.rtf	Other Canticles and Te Deum Laudamus
bcpcant.rtf	Canticles from the Book of Common Prayer


Psalter Folder (disk 2 - psalter)
p001-015.rtf	Psalms 1 to 15
p016-030.rtf	Psalms 16 to 30
p031-045.rtf	Psalms 31 to 45
p046-060.rtf	Psalms 46 to 60
p061-075.rtf	Psalms 61 to 75
p076-090.rtf	Psalms 76 to 90
p091-105.rtf	Psalms 91 to 105
p106-120.rtf	Psalms 106 to 120
p121-135.rtf	Psalms 121 to 135
p136-150.rtf	Psalms 136 to 150


*************************************************************


CONTENTS OF DISK THREE

content3.rtf	Contents of disk three
ini_intr.rtf	Initiation Services Introduction (interim ed.)
ini_cmnt.rtf	Commentary by the Liturgical Commission
		  (interim ed.)


Holy Baptism Folder (disk 3 - baptism)
bp_intro.rtf	Pastoral Introduction
baptism.rtf	Holy Baptism within a Celebration of Holy
		 Communion, Holy Baptism apart from a 
		 Celebration of Holy Communion (both taken
		 from the Main Volume)
bp_seas.rtf	Seasonal Material
bp_supl.rtf	Supplementary Texts (Main Volume) and Additional
		 Material from the President's Edition
bp_emerg.rtf	Emergency Baptism (from Pastoral Services)
bp_ch_hc.rtf	Baptism of Children within a Celebration of
		 Holy Communion (from Initiation Services)
bp_ch_sw.rtf	Baptism of Children within A Service of the Word
		 (from Initiation Services)
bp_ch_me.rtf	Baptism of Children at Morning or Evening Prayer
		 (from Initiation Services)
bp_note.rtf	Notes to Holy Baptism, Notes for Baptism within
		 a Celebration of Holy Communion and Notes
		 for Baptism at a Service of the Word (all from
		 President's Edition).


Confirmation Folder (disk 3 - confirm)
cf_af_rc.rtf	The Order for Celebration of Holy Communion with
		 Baptism and Confirmation together with
		 Affirmation of Baptismal Faith and Reception
		 into the Communion of the Church of England
cf_varia.rtf	The Order for Celebration of Holy Communion
		 with Baptism and Confirmation together with
		 Affirmation of Baptismal Faith and Reception
		 into the Communion of the Church of England
		 (Variations for when one aspect of service is
		 not to take place, eg no baptismal candidates.)
bpcf_out.rtf	Baptism and Confirmation outside the Order for
		 Celebration of Holy Communion
conf_out.rtf	Confirmation outside the Order for Celebration
		 of Holy Communion
aff_abs.rtf	Affirmation of Baptismal Faith at the Order for
		 Celebration of Holy Communion including
		 Provision in the Absence of the Bishop
rcpt_abs.rtf	Reception into the Communion of the Church of
		 England at the Order for Celebration of Holy
		 Communion including Provision in the Absence
		 of the Bishop
conf_bib.rtf	Bible Readings and Psalms at Confirmation


*************************************************************


CONTENTS OF DISK FOUR

content4.rtf	Contents of disk four
ps_intro.rtf	Introduction from the Pastoral Services book


Wholeness and Healing Folder (disk 4 - wholheal)
wh_notes.rtf	Theological Introduction and Introductory Note
wholheal.rtf	A Celebration of Wholeness and Healing
hands_hc.rtf	Laying on of Hands with Prayer and Anointing
		 at a Celebration of Holy Communion
supl_ind.rtf	Supplementary texts, Prayer for Individuals 
		 in Public Worship
minsick.rtf	Ministry to the Sick
protect.rtf	Prayers for Protection and Peace



Marriage (disk 4 - marriage)
marriage.rtf	Pastoral Introduction and the Marriage service
mrrg_hc.rtf	Marriage service within a Celebration of
		 Holy Communion
supl_mrg.rtf	Supplementary texts
civil_mg.rtf	An Order for Prayer and Dedication after a 
		 Civil Marriage
thnks_mg.rtf	Thanksgiving for Marriage


Thanksgiving for the Gift of a Child (disk 4 - thanksgv)
supl_th.rtf	Supplementary Texts and Notes
thanksgv.rtf	Thanksgiving for the Gift of a Child


Funeral  (disk 4 - funeral)
after_f.rtf	After the Funeral
before_f.rtf	Before the Funeral
fnl_chld.rtf	Outline Order for the Funeral of a Child
		 and Outline Order for the Funeral of a
		 Child within a Celebration of Holy Communion
funeral.rtf	The Funeral Service
funrl_hc.rtf	The Funeral Service within a Celebration of
		 Holy Communion
ministry.rtf	Ministry at the Time of Death
rsourc1a.rtf	Prayers for Use with the Dying and at Funeral
		 and Memorial Services (Part one - 1 to 48)
rsourc1b.rtf	Prayers for Use with the Dying and at Funeral
		 and Memorial Services (Part two - 49 to end)
rsourc2.rtf	Bible Readings and Psalms for Use at Funeral
		 and Memorial Services
rsourc3.rtf	Canticles for Use at Funeral and Memorial
		 Services
supl_fnl.rtf	Supplementary Texts


*************************************************************


Compilation and documentation copyright (c) The Archbishops' Council 2001

Texts (c) The Archbishops' Council 1998, 2000, or reproduced with permission. 

For full details see copyrt.rtf on disk one.